# -*- coding: utf-8 -*-

import os
import tkinter as tk

from AutoLamella.logic_logger import init_logging, logging
from AutoLamella.gui_main import MainGUI

if __name__ == '__main__':
    init_logging()
    logging.info('Start software')
    this_dir = os.path.dirname(os.path.realpath(__file__))  # path to this directory
    os.chdir(this_dir)  # make path to this dir the curent path
    root = tk.Tk()
    app = MainGUI(root)  # start the application
    app.mainloop()  # application is up and running
    logging.info('Finish software')
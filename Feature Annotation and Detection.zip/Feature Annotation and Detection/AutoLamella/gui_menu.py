# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

class Menu:
    """ Menu widget for the main GUI window """
    def __init__(self, master, config, shortcuts, functions, parameters):
        """ Initialize the Menu """
        self.__config = config  # obtain link on config file
        self.__shortcuts = shortcuts  # obtain link on keyboard shortcuts
        self.__functs = functions  # obtain link on dictionary of functions
        self.menubar = tk.Menu(master)  # create main menu bar, public for the main GUI
        self.empty_menu = tk.Menu(master)  # empty menu to hide the real menubar in fullscreen mode
        self.parameters = parameters # parameters for detection
        # Enable / disable these menu labels
        self.__label_recent = 'Open recent'
        self.__label_close = 'Close image'
        self.__label_tools = 'Tools'
        self.__label_2kv = 'Open 2 kV image'
        self.__label_show_squares = 'Show grid squares'
        self.__label_drawing = "Toggle drawing mode"
        self.__label_show_cells = "Show detected cells"
        self.__label_optimal_cells = "Show optimal cells"
        # Create menu for the image
        self.__file = tk.Menu(self.menubar, tearoff=False, postcommand=self.__list_recent)
        self.__file.add_command(label='Open 10 kV image (or template selection mode)',
                              command=self.__shortcuts[0][2],
                              accelerator=self.__shortcuts[0][0])
        self.__recent_images = tk.Menu(self.__file, tearoff=False)
        self.__file.add_cascade(label=self.__label_recent, menu=self.__recent_images)
        self.__file.add_command(label=self.__label_close,
                              command=self.__shortcuts[1][2],
                              accelerator=self.__shortcuts[1][0],
                              state='disabled')
        self.__file.add_command(label=self.__label_2kv,
                              command=self.__shortcuts[2][2],
                              accelerator=self.__shortcuts[2][0],
                              state='disabled')
        self.__file.add_separator()
        self.__file.add_command(label='Exit',
                              command=self.__functs['destroy'],
                              accelerator=u'Alt+F4')
        self.menubar.add_cascade(label='File', menu=self.__file)
        # Create menu for the tools: grid square detection, cell detection
        self.__tools = tk.Menu(self.menubar, tearoff=False)
        self.__tools.add_command(label='Detect grid squares',
                              command=self.__shortcuts[3][2],
                              accelerator=self.__shortcuts[3][0])
        self.__tools.add_command(label=self.__label_show_squares,
                              command=self.__shortcuts[4][2],
                              accelerator=self.__shortcuts[4][0],
                              state='disabled')
        self.__tools.add_command(label=self.__label_drawing,
                              command=self.__shortcuts[5][2],
                              accelerator=self.__shortcuts[5][0],
                              state='disabled')
        self.__tools.add_command(label='Detect cells',
                              command=self.__shortcuts[6][2],
                              accelerator=self.__shortcuts[6][0])
        self.__tools.add_command(label=self.__label_show_cells,
                              command=self.__functs['show_cells'],
                              state='disabled')
        self.__tools.add_command(label=self.__label_optimal_cells,
                              command=self.__functs['optimal_cells'],
                              state='disabled')
        self.menubar.add_cascade(label=self.__label_tools, menu=self.__tools)
        # Create menu for the view: fullscreen, default size, etc.
        self.__view = tk.Menu(self.menubar, tearoff=False)
        self.__view.add_command(label='Fullscreen',
                                command=self.__functs["toggle_fullscreen"],
                                accelerator='F11')
        self.__view.add_command(label='Default size',
                                command=self.__functs["default_geometry"],
                                accelerator='F5')
        self.menubar.add_cascade(label='View', menu=self.__view)
        # Create menu for settings: adjusting parameters for detection algorithms
        self.__settings = self.menubar.add_command(label='Settings',
                                                   command=self.__settings)
        self.__templates = tk.Menu(self.menubar, tearoff=False)
        self.__templates.add_command(label='Change template directory',
                                                   command=self.__functs["change_templates_dir"])
        self.__templates.add_command(label='Preview templates',
                              command=self.__functs['preview_templates'])
        self.menubar.add_cascade(label='Templates', menu=self.__templates)
        # Create menu for help: includes instructions and credits.
        self.__help = tk.Menu(self.menubar, tearoff=False)
        self.__help.add_command(label='About', command=self.__about)
        self.menubar.add_cascade(label='Help', menu=self.__help)
        
    def __about(self):
        self.__about_window = tk.Toplevel()
        self.__about_window.title("About")
        self.__about_window.geometry("200x200")
        self.__about_text = tk.Text(self.__about_window, height=5, width=52)
        self.__about_display_text = """"Yo, homies. What's up?"""
        self.__about_text.insert(tk.END, self.__about_display_text)
        self.__about_text.pack()
        
    def __settings(self):
        """Open the settings window."""
        settings_window = tk.Toplevel()
        settings_window.title("Settings")

        # Create a frame to hold the settings
        frame = ttk.Frame(settings_window, padding=10)
        frame.grid(row=0, column=0, sticky="nsew")

        # Input fields for each parameter
        entries = {}
        for idx, (param, value) in enumerate(self.parameters.items()):
            ttk.Label(frame, text=param).grid(row=idx, column=0, sticky="w", padx=5, pady=5)
            if isinstance(value, bool):
                # Use Checkbutton for boolean parameters
                var = tk.BooleanVar(value=value)
                checkbutton = ttk.Checkbutton(frame, variable=var)
                checkbutton.grid(row=idx, column=1, sticky="w", padx=5, pady=5)
                entries[param] = var
            elif isinstance(value, (int, float)):
                # Use Entry for numerical parameters
                entry = ttk.Entry(frame)
                entry.grid(row=idx, column=1, sticky="ew", padx=5, pady=5)
                entry.insert(0, value)  # Set the current parameter value
                entries[param] = entry

        # Buttons to apply or cancel changes
        def apply_changes():
            """Apply changes to the parameters."""
            for param, entry in entries.items():
                if isinstance(self.parameters[param], bool):
                    # For boolean parameters, get the value from the BooleanVar
                    self.parameters[param] = entry.get()
                else:
                    try:
                        self.parameters[param] = type(self.parameters[param])(entry.get())
                    except ValueError:
                        messagebox.showerror("Invalid Value", f"Please enter a valid value for {param}.")
                        return
            self.__functs['set_params'](self.parameters)
            settings_window.destroy()

        def cancel_changes():
            """Close the settings window without saving."""
            settings_window.destroy()

        ttk.Button(frame, text="Apply", command=apply_changes).grid(row=len(self.parameters), column=0, pady=10)
        ttk.Button(frame, text="Cancel", command=cancel_changes).grid(row=len(self.parameters), column=1, pady=10)


    def __list_recent(self):
        """ List of the recent images """
        self.__recent_images.delete(0, 'end')  # empty previous list
        lst = self.__config.get_recent_list()  # get list of recently opened images
        for path in lst:  # get list of recent image paths
            self.__recent_images.add_command(label=path,
                                             command=lambda x=path: self.__functs["set_image"](x))
        # Disable recent list menu if it is empty.
        if self.__recent_images.index('end') is None:
            self.__file.entryconfigure(self.__label_recent, state='disabled')
        else:
            self.__file.entryconfigure(self.__label_recent, state='normal')


    def set_state(self, state):
        """ Enable / disable some menus """
        self.menubar.entryconfigure(self.__label_tools, state=state)
        self.__file.entryconfigure(self.__label_close, state=state)
        
    
    def set_2kv_state(self, state):
        """ Enable / disable the 2kv image option """
        self.__file.entryconfigure(self.__label_2kv, state=state)
    
    def set_show_squares_state(self, state):
        """ Enable / disable the grid squares display option """
        self.__tools.entryconfigure(self.__label_show_squares, state=state)
        
    def set_drawing_state(self, state):
        """ Enable / disable the drawing option """
        self.__tools.entryconfigure(self.__label_drawing, state=state)
        
    def set_cells_state(self, state):
        self.__tools.entryconfigure(self.__label_show_cells, state=state)
        self.__tools.entryconfigure(self.__label_optimal_cells, state=state)
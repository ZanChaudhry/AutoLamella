# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import Toplevel, Button, Canvas, Frame
from PIL import Image, ImageTk
import numpy as np

class ArrayPhotoViewer:
    def __init__(self, master, arrays):
        """
        Initialize the Photo Viewer in a Toplevel window with Canvas.

        Parameters:
        - arrays: List of lists [NumPy array, path] to display as images
        """
        self.arrays = arrays
        self.current_index = 0

        # Create a new Toplevel window
        self.window = Toplevel(master)
        self.window.title("Template viewer")
        self.window.resizable(False, False)  # Prevent fullscreen resizing

        # Get screen dimensions
        self.screen_width = self.window.winfo_screenwidth()
        self.screen_height = self.window.winfo_screenheight()

        # Frame to hold Canvas and Buttons
        self.canvas_frame = Frame(self.window)
        self.canvas_frame.pack(side="top", expand=True, fill="both")

        # Create Canvas for displaying images
        self.canvas = Canvas(self.canvas_frame, bg="white", highlightthickness=0)
        self.canvas.pack(expand=True, fill="both")

        # Navigation buttons in a separate frame
        button_frame = Frame(self.window)
        button_frame.pack(side="bottom", fill="x", pady=5)

        self.prev_button = Button(button_frame, text="<< Previous", command=self.show_previous)
        self.prev_button.pack(side="left", padx=10)

        self.next_button = Button(button_frame, text="Next >>", command=self.show_next)
        self.next_button.pack(side="right", padx=10)

        # Display the first image
        self.show_image(self.current_index)

    def array_to_image(self, array):
        """Convert a NumPy array to a Pillow Image."""
        normalized = (255 * array).astype(np.uint8)  # Normalize to 0-255
        return Image.fromarray(normalized)

    def resize_image_to_fit_screen(self, image):
        """Resize the image to fit the screen if it's too large."""
        img_width, img_height = image.size
        max_width, max_height = self.screen_width * 0.9, self.screen_height * 0.8  # Leave margins

        if img_width > max_width or img_height > max_height:
            # Scale down the image while maintaining aspect ratio
            scale_factor = min(max_width / img_width, max_height / img_height)
            new_width = int(img_width * scale_factor)
            new_height = int(img_height * scale_factor)
            return image.resize((new_width, new_height), Image.LANCZOS)
        return image

    def show_image(self, index):
        """Show the image at the given index with minimum canvas size."""
        if 0 <= index < len(self.arrays):
            # Convert the array to an image
            image = self.array_to_image(self.arrays[index][0])
            im_path = self.arrays[index][1]
    
            # Resize the image to fit the screen if needed
            image = self.resize_image_to_fit_screen(image)
    
            # Define minimum canvas size
            min_canvas_width = 300  # Minimum width for buttons to look good
            min_canvas_height = 300  # Minimum height for display
    
            # Enforce minimum size for canvas
            canvas_width = max(image.width, min_canvas_width)
            canvas_height = max(image.height, min_canvas_height)
    
            # Convert to ImageTk for display on the Canvas
            self.tk_image = ImageTk.PhotoImage(image)
    
            # Clear the Canvas and display the image centered
            self.canvas.delete("all")
            self.canvas.config(width=canvas_width, height=canvas_height)
            x_offset = (canvas_width - image.width) // 2
            y_offset = (canvas_height - image.height) // 2
            self.canvas.create_image(x_offset, y_offset, anchor="nw", image=self.tk_image)
    
            # Update the window geometry to fit the canvas and buttons
            button_height = 50  # Approximate height of button frame
            self.window.geometry(f"{canvas_width}x{canvas_height + button_height}")
    
            # Update the window title
            self.window.title(f"Template viewer: {im_path}")

    def show_next(self):
        """Display the next image."""
        if self.current_index < len(self.arrays) - 1:
            self.current_index += 1
            self.show_image(self.current_index)

    def show_previous(self):
        """Display the previous image."""
        if self.current_index > 0:
            self.current_index -= 1
            self.show_image(self.current_index)
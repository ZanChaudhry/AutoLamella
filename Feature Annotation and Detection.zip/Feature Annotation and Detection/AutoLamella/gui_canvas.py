# -*- coding: utf-8 -*-

# Canvas widget to zoom image.
import os
import math
import hashlib
import warnings
import tkinter as tk

from tkinter import ttk
from PIL import Image, ImageTk
from .logic_logger import logging
from .gui_autoscrollbar import AutoScrollbar
import numpy as np
import time

MAX_IMAGE_PIXELS = 1500000000  # maximum pixels in the image, use it carefully


class CanvasImage:
    """ Display and zoom image """

    def __init__(self, placeholder, path=None, array=None):
        """ Initialize the ImageFrame """
        self.__array = array # if there is an array, use it instead of path
        self.imscale = 1.0  # scale for the canvas image zoom, public for outer classes
        self.__im_array = None
        self.__delta = 1.3  # zoom magnitude
        # could be: NEAREST, BILINEAR, BICUBIC and ANTIALIAS -- Changed to LANCSOZ based on updates
        self.__filter = Image.LANCZOS
        self.__previous_state = 0  # previous state of the keyboard
        self.path = path  # path to the image, should be public for outer classes
        # Create ImageFrame in placeholder widget
        # placeholder of the ImageFrame object
        self.__imframe = ttk.Frame(placeholder)
        # Vertical and horizontal scrollbars for canvas
        self.hbar = AutoScrollbar(self.__imframe, orient='horizontal')
        self.vbar = AutoScrollbar(self.__imframe, orient='vertical')
        self.hbar.grid(row=1, column=0, sticky='we')
        self.vbar.grid(row=0, column=1, sticky='ns')
        # Create canvas and bind it with scrollbars. Public for outer classes
        self.canvas = tk.Canvas(self.__imframe, highlightthickness=0,
                                xscrollcommand=self.hbar.set, yscrollcommand=self.vbar.set)
        self.canvas.grid(row=0, column=0, sticky='nswe')
        self.canvas.update()  # wait till canvas is created

        # bind scrollbars to the canvas
        self.hbar.configure(command=self.__scroll_x)
        self.vbar.configure(command=self.__scroll_y)

        
        self.drawing = False  # Flag to indicate drawing mode
        self.rect = None  # Reference to the rectangle being drawn
        self.start_x = None  # Start x-coordinate for the rectangle
        self.start_y = None  # Start y-coordinate for the rectangle
        self.template_dir = None  # Directory to save templates

        # Bind events to the Canvas
        # canvas is resized
        self.canvas.bind('<Configure>', lambda event: self.__show_image())
        # Handle keystrokes in idle mode, because program slows down on a weak computers,
        # when too many key stroke events in the same time
        self.canvas.bind('<Key>', lambda event: self.canvas.after_idle(
            self.__keystroke, event))
        if self.__array is not None:
                logging.info('Open image: Processing')
        else:
                logging.info('Open image: {}'.format(self.path))

        # Decide if this image huge or not
        self.__huge = False  # huge or not
        self.__huge_size = 14000  # define size of the huge image
        self.__band_width = 1024  # width of the tile band
        # suppress DecompressionBombError for big image
        Image.MAX_IMAGE_PIXELS = MAX_IMAGE_PIXELS
        if self.__array is not None:
            self.__image = Image.fromarray(self.__array.astype(np.uint8))
        else:
            with warnings.catch_warnings():  # suppress DecompressionBombWarning for big image
                warnings.simplefilter('ignore')
                # open image, but don't load it into RAM
                self.__image = Image.open(self.path)
                self.__im_array = np.array(self.__image)
                
        self.imwidth, self.imheight = self.__image.size  # public for outer classes
        if self.imwidth * self.imheight > self.__huge_size * self.__huge_size and \
            self.__array is None:  # only raw images could be tiled
            if hasattr(self.__image, 'tile') and self.__image.tile and self.__image.tile[0][0] == 'raw':
                self.__huge = True  # image is huge
                self.__offset = self.__image.tile[0][2]  # initial tile offset
                self.__tile = [self.__image.tile[0][0],  # it have to be 'raw'
                               # tile extent (a rectangle)
                               [0, 0, self.imwidth, 0],
                               self.__offset,
                               self.__image.tile[0][3]]  # list of arguments to the decoder
        # get the smaller image side
        self.__min_side = min(self.imwidth, self.imheight)
        # Create image pyramid
        if self.__array is not None:
            self.__pyramid = [Image.fromarray(self.__array.astype(np.uint8))]
        else:
            self.__pyramid = [self.smaller()] if self.__huge else [
                Image.open(self.path)]
        # Set ratio coefficient for image pyramid
        self.__ratio = max(self.imwidth, self.imheight) / \
            self.__huge_size if self.__huge else 1.0
        self.__curr_img = 0  # current image from the pyramid
        self.__scale = self.imscale * self.__ratio  # image pyramide scale
        self.__reduction = 2  # reduction degree of image pyramid
        (w, h), m, j = self.__pyramid[-1].size, 512, 0
        n = math.ceil(math.log(min(w, h) / m, self.__reduction)
                      ) + 1  # image pyramid length
        while w > m and h > m:  # top pyramid image is around 512 pixels in size
            j += 1
            print('\rCreating image pyramid: {j} from {n}'.format(
                j=j, n=n), end='')
            w /= self.__reduction  # divide on reduction degree
            h /= self.__reduction  # divide on reduction degree
            self.__pyramid.append(
                self.__pyramid[-1].resize((int(w), int(h)), self.__filter))
        print('\r' + (40 * ' ') + '\r', end='')  # hide printed string
        # Put image into container rectangle and use it to set proper coordinates to the image
        self.container = self.canvas.create_rectangle(
            (0, 0, self.imwidth, self.imheight), width=0)
        # Create MD5 hash sum from the image. Public for outer classes
        self.md5 = hashlib.md5(self.__pyramid[0].tobytes()).hexdigest()
        # Initialize square
        self.square_size = 50  # Default size of the square
        self.rotation_angle = 0  # Rotation angle in degrees (0 by default)
        self.square = None     # Reference to the square object on the canvas
        self.circle_size = 20 # Defalut size of the circle representing the cell
        self.circle = None # Reference to the circle object on the canvas
        self.__create_square_and_circle()
        
        self.__show_image()  # show image on the canvas
        self.canvas.focus_set()  # set focus on the canvas

        # Bind events for square size adjustment
        self.canvas.bind('<Key>', self.__keystroke)
        
        # Set up drawing mode bindings
        self.__setup_bindings()

    def __setup_bindings(self):
        """Set up bindings for mouse and drawing events."""
        self.canvas.bind("<ButtonPress-1>", self.__start_drawing)  # Left click: Start drawing
        self.canvas.bind("<B1-Motion>", self.__draw_rectangle)     # Drag left mouse: Draw rectangle
        self.canvas.bind("<ButtonRelease-1>", self.__finish_drawing)  # Release left mouse: Finish rectangle
    
        # Right-click behavior: Context menu for drawing mode, pan otherwise
        self.canvas.bind("<Button-3>", self.__right_click_handler)
        self.canvas.bind("<B3-Motion>", self.__move_to)  # Dragging with right mouse
    
        # Scroll and zoom bindings
        self.canvas.bind("<MouseWheel>", self.__wheel)
        self.canvas.bind("<Button-5>", self.__wheel)  # Linux scroll down
        self.canvas.bind("<Button-4>", self.__wheel)  # Linux scroll up

    def __start_drawing(self, event):
        """Start drawing the rectangle."""
        if not self.drawing:
            return
        self.start_x = self.canvas.canvasx(event.x)
        self.start_y = self.canvas.canvasy(event.y)
        self.rect = self.canvas.create_rectangle(
            self.start_x, self.start_y, self.start_x, self.start_y, outline="green", width=5
        )

    def __draw_rectangle(self, event):
        """Draw the rectangle as the user drags the mouse."""
        if not self.drawing or not self.rect:
            return
        end_x = self.canvas.canvasx(event.x)
        end_y = self.canvas.canvasy(event.y)
        self.canvas.coords(self.rect, self.start_x, self.start_y, end_x, end_y)

    def __finish_drawing(self, event):
        """Finalize drawing the rectangle."""
        if not self.drawing or not self.rect:
            return
        self.drawing = False  # Stop drawing mode to end rectangle

    def __right_click_menu(self, event):
        """Show a context menu for the drawn rectangle."""
        if not self.rect:
            return

        menu = tk.Menu(self.canvas, tearoff=0)
        menu.add_command(label="Save as Template", command=self.__save_rectangle)
        menu.add_command(label="Delete Rectangle", command=self.__delete_rectangle)
        menu.post(event.x_root, event.y_root)

    def __delete_rectangle(self):
        """Delete the drawn rectangle."""
        if self.rect:
            self.canvas.delete(self.rect)
            self.rect = None
            self.drawing=True

    def __save_rectangle(self):
        """Save the drawn rectangle as a template."""
        if not self.rect:
            return

        bbox = self.canvas.coords(self.container)  # get image area
        # Get rectangle coordinates on the canvas
        c_x1, c_y1, c_x2, c_y2 = map(int, self.canvas.coords(self.rect))
        # get real (x,y) on the image without zoom
        x1 = round((c_x1 - bbox[0]) / self.imscale)  
        x2 = round((c_x2 - bbox[0]) / self.imscale)  
        y1 = round((c_y1 - bbox[1]) / self.imscale)
        y2 = round((c_y2 - bbox[1]) / self.imscale)
        

        # Extract the region from the original image array
        template = self.__im_array[y1:y2, x1:x2]
        
        # Save the template - make sure to not edit defaults
        if os.path.abspath(self.template_dir).endswith(os.path.join('templates', 'default')):
            logging.warning('Cannot modify defaults! Choose a different templates directory')
            return
        else:
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            save_path = os.path.join(self.template_dir, f"template_{timestamp}.png")
            template_image = Image.fromarray(template)
            template_image.save(save_path)
            logging.info(f"Template saved to {save_path}")

        # Clean up the rectangle
        self.__delete_rectangle()
        self.drawing = True

    def __create_square_and_circle(self):
        """Create the square on the canvas."""
        if self.square:
            self.canvas.delete(self.square)
        if self.circle:
            self.circle.delete(self.circle)
            
        # Draw square
        self.square = self.canvas.create_polygon(0, 0, 0, 0, 0, 0, 0, 0,
                                                 outline="red", fill="", width=5)

        # Draw circle
        self.circle = self.canvas.create_oval(
            0, 0, 0, 0, outline="blue", width=3
        )

        # Position it correctly on initialization
        self.__update_square_and_circle_position()

    def __update_square_and_circle_position(self):
        """Reposition the square to the bottom-left of the current visible area."""
        # Get the current visible region of the canvas
        x1, y1, x2, y2 = self.canvas.canvasx(0), self.canvas.canvasy(0), \
            self.canvas.canvasx(self.canvas.winfo_width()), \
            self.canvas.canvasy(self.canvas.winfo_height())

        # Calculate the square's new center to keep it within bounds
        # Half of the diagonal length
        half_diag = (self.square_size / math.sqrt(2))
        buffer = 10  # Margin to keep the square inside the visible area

        # Calculate new center position
        cx = x1 + half_diag + buffer
        cy = y2 - half_diag - buffer

        # Calculate the rotated vertices of the square
        angle_rad = math.radians(self.rotation_angle)
        vertices = []
        for dx, dy in [(-self.square_size / 2, -self.square_size / 2),
                       (self.square_size / 2, -self.square_size / 2),
                       (self.square_size / 2, self.square_size / 2),
                       (-self.square_size / 2, self.square_size / 2)]:
            # Apply rotation transformation
            x_rot = cx + (dx * math.cos(angle_rad) - dy * math.sin(angle_rad))
            y_rot = cy + (dx * math.sin(angle_rad) + dy * math.cos(angle_rad))
            vertices.extend([x_rot, y_rot])

        # Update the square's coordinates
        self.canvas.coords(self.square, *vertices)
        
        # Circle coordinates
        circle_x1 = cx - self.circle_size / 2
        circle_y1 = cy - self.circle_size / 2
        circle_x2 = cx + self.circle_size / 2
        circle_y2 = cy + self.circle_size / 2

        # Update circle position
        self.canvas.coords(self.circle, circle_x1, circle_y1, circle_x2, circle_y2)

    def rotate_square(self, delta_angle):
        """Rotate the square by a specified angle."""
        self.rotation_angle = (self.rotation_angle +
                               delta_angle) % 360  # Keep angle in [0, 360]
        self.__update_square_and_circle_position()

    def adjust_square_size(self, delta):
        """Adjust the size of the square and redraw it."""
        new_size = self.square_size + delta
        if new_size > 10:  # Minimum size for the square
            self.square_size = new_size
            self.__update_square_and_circle_position()  # Redraw with updated size
    
    def adjust_circle_size(self, delta):
        new_size = self.circle_size + delta
        if (new_size > 5) and (new_size <= self.square_size):  # Minimum size for the circle
            self.circle_size = new_size
            self.__update_square_and_circle_position()  # Redraw with updated size        

    def smaller(self):
        """Resize image proportionally and return a smaller image."""
        w1, h1 = float(self.imwidth), float(self.imheight)
        w2, h2 = float(self.__huge_size), float(self.__huge_size)
        aspect_ratio1 = w1 / h1
        aspect_ratio2 = w2 / h2  # For square dimensions
    
        if aspect_ratio1 == aspect_ratio2:
            image = Image.new('RGB', (int(w2), int(h2)))
            k = h2 / h1  # Compression ratio
            w = int(w2)  # Final band width
        elif aspect_ratio1 > aspect_ratio2:
            image = Image.new('RGB', (int(w2), int(w2 / aspect_ratio1)))
            k = w2 / w1  # Compression ratio
            w = int(w2)  # Final band width
        else:  # aspect_ratio1 < aspect_ratio2
            image = Image.new('RGB', (int(h2 * aspect_ratio1), int(h2)))
            k = h2 / h1  # Compression ratio
            w = int(h2 * aspect_ratio1)  # Final band width
    
        i, j, n = 0, 0, math.ceil(self.imheight / self.__band_width)
    
        while i < self.imheight:
            j += 1
            print('\rOpening image: {j} from {n}'.format(j=j, n=n), end='')
    
            # Band height and boundaries
            band = min(self.__band_width, self.imheight - i)
            top = i
            bottom = min(self.imheight, i + band)
    
            # Reopen/reset the image for the current band
            if self.__array is not None:
                self.__image = Image.fromarray(self.__array.astype(np.uint8))
            else:
                self.__image = Image.open(self.path)
                self.__image.draft("RGB", (self.imwidth, band))  # Use draft mode for large images
    
            # Ensure valid cropping boundaries
            cropped = self.__image.crop((0, top, self.imwidth, bottom))  # Crop the current band
    
            # Resize the cropped band and paste onto the final image
            resized_band = cropped.resize((w, int(band * k) + 1), self.__filter)
            image.paste(resized_band, (0, int(i * k)))
    
            i += band  # Move to the next band
    
        print('\r' + (40 * ' ') + '\r', end='')  # Clear the progress line
        return image



    @staticmethod
    def check_image(path):
        """ Check if it is an image. Static method """
        # noinspection PyBroadException
        try:  # try to open and close image with PIL
            # suppress DecompressionBombError for big image
            Image.MAX_IMAGE_PIXELS = MAX_IMAGE_PIXELS
            with warnings.catch_warnings():  # suppress DecompressionBombWarning for big image
                warnings.simplefilter(u'ignore')
                img = Image.open(path)
            img.close()
        except:
            return False  # not image
        return True  # image

    def redraw_figures(self):
        """ Dummy function to redraw figures in the children classes """
        self.__update_square_and_circle_position() # Ensure the square is updated
        pass

    def grid(self, **kw):
        """ Put CanvasImage widget on the parent widget """
        self.__imframe.grid(**kw)  # place CanvasImage widget on the grid
        self.__imframe.grid(sticky='nswe')  # make frame container sticky
        self.__imframe.rowconfigure(0, weight=1)  # make canvas expandable
        self.__imframe.columnconfigure(0, weight=1)

    def pack(self, **kw):
        """ Exception: cannot use pack with this widget """
        raise Exception('Cannot use pack with the widget ' +
                        self.__class__.__name__)

    def place(self, **kw):
        """ Exception: cannot use place with this widget """
        raise Exception('Cannot use place with the widget ' +
                        self.__class__.__name__)

    # noinspection PyUnusedLocal
    def __scroll_x(self, *args, **kwargs):
        """ Scroll canvas horizontally and redraw the image """
        self.canvas.xview(*args)  # scroll horizontally
        self.__show_image()  # redraw the image

    # noinspection PyUnusedLocal
    def __scroll_y(self, *args, **kwargs):
        """ Scroll canvas vertically and redraw the image """
        self.canvas.yview(*args)  # scroll vertically
        self.__show_image()  # redraw the image

    def __show_image(self):
        """ Show image on the Canvas. Implements correct image zoom almost like in Google Maps """
        box_image = self.canvas.coords(self.container)  # get image area
        box_canvas = (self.canvas.canvasx(0),  # get visible area of the canvas
                      self.canvas.canvasy(0),
                      self.canvas.canvasx(self.canvas.winfo_width()),
                      self.canvas.canvasy(self.canvas.winfo_height()))
        # convert to integer or it will not work properly
        box_img_int = tuple(map(int, box_image))
        # Get scroll region box
        box_scroll = [min(box_img_int[0], box_canvas[0]), min(box_img_int[1], box_canvas[1]),
                      max(box_img_int[2], box_canvas[2]), max(box_img_int[3], box_canvas[3])]
        # Horizontal part of the image is in the visible area
        if box_scroll[0] == box_canvas[0] and box_scroll[2] == box_canvas[2]:
            box_scroll[0] = box_img_int[0]
            box_scroll[2] = box_img_int[2]
        # Vertical part of the image is in the visible area
        if box_scroll[1] == box_canvas[1] and box_scroll[3] == box_canvas[3]:
            box_scroll[1] = box_img_int[1]
            box_scroll[3] = box_img_int[3]
        # Convert scroll region to tuple and to integer
        self.canvas.configure(scrollregion=tuple(
            map(int, box_scroll)))  # set scroll region
        # get coordinates (x1,y1,x2,y2) of the image tile
        x1 = max(box_canvas[0] - box_image[0], 0)
        y1 = max(box_canvas[1] - box_image[1], 0)
        x2 = min(box_canvas[2], box_image[2]) - box_image[0]
        y2 = min(box_canvas[3], box_image[3]) - box_image[1]
        if int(x2 - x1) > 0 and int(y2 - y1) > 0:  # show image if it in the visible area
            if self.__huge and self.__curr_img < 0:  # show huge image, which does not fit in RAM
                h = int((y2 - y1) / self.imscale)  # height of the tile band
                self.__tile[1][3] = h  # set the tile band height
                self.__tile[2] = self.__offset + \
                    self.imwidth * int(y1 / self.imscale) * 3
                self.__image.close()
                if self.__array is not None:
                    self.__image = Image.fromarray(self.__array.astype(np.uint8))
                else:
                    self.__image = Image.open(self.path)  # reopen / reset image
                # set size of the tile band
                self.__image.size = (self.imwidth, h)
                self.__image.tile = [self.__tile]
                image = self.__image.crop(
                    (int(x1 / self.imscale), 0, int(x2 / self.imscale), h))
            else:  # show normal image
                image = self.__pyramid[max(0, self.__curr_img)].crop(  # crop current img from pyramid
                    (int(x1 / self.__scale), int(y1 / self.__scale),
                     int(x2 / self.__scale), int(y2 / self.__scale)))
            #
            imagetk = ImageTk.PhotoImage(image.resize(
                (int(x2 - x1), int(y2 - y1)), self.__filter), master=self.canvas)
            imageid = self.canvas.create_image(max(box_canvas[0], box_img_int[0]),
                                               max(box_canvas[1],
                                                   box_img_int[1]),
                                               anchor='nw', image=imagetk)
            self.canvas.lower(imageid)  # set image into background
            # keep an extra reference to prevent garbage-collection
            self.canvas.imagetk = imagetk

        self.redraw_figures()  # Ensure figures are redrawn correctly
        self.__update_square_and_circle_position()

    def __move_from(self, event):
        """ Remember previous coordinates for scrolling with the mouse """
        self.canvas.scan_mark(event.x, event.y)

    def __right_click_handler(self, event):
        """Handle right-click based on the mode."""
        if self.rect is not None:
            # Show context menu only in drawing mode
            menu = tk.Menu(self.canvas, tearoff=0)
            menu.add_command(label="Save as template", command=self.__save_rectangle)
            menu.add_command(label="Delete rectangle", command=self.__delete_rectangle)
            menu.post(event.x_root, event.y_root)
        else:
            # Trigger normal dragging functionality if not in drawing mode
            self.__move_from(event)

    def __move_to(self, event):
        """ Drag (move) canvas to the new position """
        if self.rect is None:
            self.canvas.scan_dragto(event.x, event.y, gain=1)
            self.__show_image()  # zoom tile and show it on the canvas

    def __drag_image(self, event):
        """Drag the image when not in drawing mode."""
        if not self.drawing:
            self.__move_to(event)

    def outside(self, x, y):
        """ Checks if the point (x,y) is outside the image area """
        bbox = self.canvas.coords(self.container)  # get image area
        if bbox[0] < x < bbox[2] and bbox[1] < y < bbox[3]:
            return False  # point (x,y) is inside the image area
        else:
            return True  # point (x,y) is outside the image area

    def __wheel(self, event):
        """ Zoom with mouse wheel """
        x = self.canvas.canvasx(
            event.x)  # get coordinates of the event on the canvas
        y = self.canvas.canvasy(event.y)
        if self.outside(x, y):
            return  # zoom only inside image area
        scale = 1.0
        # Respond to Linux (event.num) or Windows (event.delta) wheel event
        if event.num == 5 or event.delta == -120:  # scroll down, zoom out, smaller
            if round(self.__min_side * self.imscale) < 30:
                return  # image is less than 30 pixels
            self.imscale /= self.__delta
            scale /= self.__delta
        if event.num == 4 or event.delta == 120:  # scroll up, zoom in, bigger
            i = float(min(self.canvas.winfo_width(),
                      self.canvas.winfo_height()) >> 1)
            if i < self.imscale:
                return  # 1 pixel is bigger than the visible area
            self.imscale *= self.__delta
            scale *= self.__delta
        # Take appropriate image from the pyramid
        k = self.imscale * self.__ratio  # temporary coefficient
        self.__curr_img = min(
            (-1) * int(math.log(k, self.__reduction)), len(self.__pyramid) - 1)
        self.__scale = k * math.pow(self.__reduction, max(0, self.__curr_img))
        #
        self.canvas.scale('all', x, y, scale, scale)  # rescale all objects
        # Redraw some figures before showing image on the screen
        self.redraw_figures()  # method for child classes
        self.__show_image()

    def __keystroke(self, event):
        """ Scrolling with the keyboard.
            Independent from the language of the keyboard, CapsLock, <Ctrl>+<key>, etc. """
        if event.state - self.__previous_state == 4:  # means that the Control key is pressed
            pass  # do nothing if Control key is pressed
        else:
            self.__previous_state = event.state  # remember the last keystroke state
            # Up, Down, Left, Right keystrokes
            self.keycodes = {}  # init key codes
            if os.name == 'nt':  # Windows OS
                self.keycodes = {
                    'd': [68, 39, 102],
                    'a': [65, 37, 100],
                    'w': [87, 38, 104],
                    's': [83, 40,  98],
                }
            else:  # Linux OS
                self.keycodes = {
                    'd': [40, 114, 85],
                    'a': [38, 113, 83],
                    'w': [25, 111, 80],
                    's': [39, 116, 88],
                }
            # scroll right, keys 'd' or 'Right'
            if event.keycode in self.keycodes['d']:
                self.__scroll_x('scroll',  1, 'unit', event=event)
            # scroll left, keys 'a' or 'Left'
            elif event.keycode in self.keycodes['a']:
                self.__scroll_x('scroll', -1, 'unit', event=event)
            # scroll up, keys 'w' or 'Up'
            elif event.keycode in self.keycodes['w']:
                self.__scroll_y('scroll', -1, 'unit', event=event)
            # scroll down, keys 's' or 'Down'
            elif event.keycode in self.keycodes['s']:
                self.__scroll_y('scroll',  1, 'unit', event=event)
            elif event.char == '=':
                self.adjust_square_size(5)  # Increase square size
            elif event.char == '-':
                self.adjust_square_size(-5)  # Decrease square size
            elif event.char == '.':
                self.adjust_circle_size(3)  # Increase square size
            elif event.char == ',':
                self.adjust_circle_size(-3)  # Decrease square size
            elif event.char == '[':
                self.rotate_square(-3)  # Rotate counterclockwise
            elif event.char == ']':
                self.rotate_square(3)  # Rotate clockwise

    def crop(self, bbox):
        """ Crop rectangle from the image and return it """
        if self.__huge:  # image is huge and not totally in RAM
            band = bbox[3] - bbox[1]  # width of the tile band
            self.__tile[1][3] = band  # set the tile height
            self.__tile[2] = self.__offset + self.imwidth * \
                bbox[1] * 3  # set offset of the band
            self.__image.close()
            if self.__array is not None:
                self.__image = Image.fromarray(self._array.astype(np.uint8))  # reopen / reset image
            else:
                self.__image = Image.open(self.path)  # reopen / reset image
            # set size of the tile band
            self.__image.size = (self.imwidth, band)
            self.__image.tile = [self.__tile]
            return self.__image.crop((bbox[0], 0, bbox[2], band))
        else:  # image is totally in RAM
            return self.__pyramid[0].crop(bbox)

    def destroy(self):
        """ ImageFrame destructor """
        if self.__array is not None:
            logging.info('Close image: Processing')
        else:
            logging.info('Close image: {}'.format(self.path))
            
        self.__image.close()
        map(lambda i: i.close, self.__pyramid)  # close all pyramid images
        del self.__pyramid[:]  # delete pyramid list
        del self.__pyramid  # delete pyramid variable
        self.canvas.destroy()
        self.__imframe.destroy()

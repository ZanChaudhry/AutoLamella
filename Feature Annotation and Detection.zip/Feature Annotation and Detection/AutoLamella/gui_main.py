# -*- coding: utf-8 -*-

import os

from tkinter import ttk
from tkinter import messagebox
from tkinter.filedialog import askopenfilename, askdirectory
from .gui_menu import Menu
from .gui_canvas import CanvasImage
from .gui_templateviewer import ArrayPhotoViewer
from .logic_config import Config
from .logic_logger import logging, handle_exception
import numpy as np
import cv2 as cv
from sklearn.cluster import DBSCAN
from PIL import Image
from MTM import matchTemplates
import random
from scipy import ndimage
import copy

class MainGUI(ttk.Frame):
    """ Main GUI Window """
    def __init__(self, mainframe):
        """ Initialize the Frame """
        logging.info('Open GUI')
        ttk.Frame.__init__(self, master=mainframe)
        
        # Grid square detection parameters
        self.__millable_centers = None
        self.__detected_squares_array = None
        self.__full_square_size = None
        self.__square_rotation_angle = None
        
        # Cell detection parameters
        self.__full_circle_size = None
        
        # Window setup
        self.__create_instances()
        self.__create_main_window()
        self.__create_widgets()


    def __create_instances(self):
        """ Instances for GUI are created here """
        self.__config = Config()  # open config file of the main window
        self.__imframe = None  # empty instance of image frame (canvas)

    def __create_main_window(self):
        """ Create main window GUI """
        self.__default_title = 'AutoLamella'
        self.master.title(self.__default_title)
        self.master.geometry(self.__config.get_win_geometry())  # get window size/position from config
        self.master.wm_state(self.__config.get_win_state())  # get window state
        # self.destructor gets fired when the window is destroyed
        self.master.protocol('WM_DELETE_WINDOW', self.destroy_)
        #
        self.__fullscreen = False  # enable / disable fullscreen mode
        self.__bugfix = False  # BUG! when change: fullscreen --> zoomed --> normal
        self.__previous_state = 0  # previous state of the event
        # List of shortcuts in the following format: [name, keycode, function]
        self.keycode = {}  # init key codes
        if os.name == 'nt':  # Windows OS
            self.keycode = {
                'o': 79,
                'w': 87,
                'r': 82,
                'q': 81,
                'h': 72,
                's': 83,
                'a': 65,
            }
        else:  # Linux OS
            self.keycode = {
                'o': 32,
                'w': 25,
                'r': 27,
                'q': 24,
                'h': 43,
                's': 39,
                'a': 38,
            }
        self.__shortcuts = [['Ctrl+O', self.keycode['o'], self.__open_image],   # 0 open image (10 kV or template mode)
                            ['Ctrl+W', self.keycode['w'], self.__close_image],  # 1 close image
                            ['Ctrl+R', self.keycode['r'], self.__open_image],   # 2 open image (2 kV for cell detection) 
                            ['Ctrl+S', self.keycode['s'], self.grid_squares],   # 3 run grid square detection                        
                            ['Ctrl+A', self.keycode['a'], self.show_grid_squares], # 4 show detected grid squares
                            ['Ctrl+H', self.keycode['h'], self.__toggle_drawing_mode], # 5 toggle template drawing mode
                            ['Ctrl+Q', self.keycode['q'], self.multi_template_matching] # 6 run cell detection
                            ]
        # Bind events to the main window
        self.master.bind('<Motion>', lambda event: self.__motion())  # track and handle mouse pointer position
        self.master.bind('<F11>', lambda event: self.__toggle_fullscreen())  # toggle fullscreen mode
        self.master.bind('<Escape>', lambda event, s=False: self.__toggle_fullscreen(s))
        self.master.bind('<F5>', lambda event: self.__default_geometry())  # reset default window geometry
        # Handle main window resizing in the idle mode, because consecutive keystrokes <F11> - <F5>
        # don't set default geometry from full screen if resizing is not postponed.
        self.master.bind('<Configure>', lambda event: self.master.after_idle(self.__resize_master))
        # Handle keystrokes in the idle mode, because program slows down on a weak computers,
        # when too many key stroke events in the same time.
        self.master.bind('<Key>', lambda event: self.master.after_idle(self.__keystroke, event))

    def __toggle_drawing_mode(self):
        if self.__imframe is not None:
            self.__imframe.drawing = not self.__imframe.drawing
            if self.__imframe.drawing:
                self.master.title(self.master.title() + " - Drawing mode enabled")
                self.__imframe.template_dir = self.__config.get_templates_path()
            else:
                self.master.title(self.master.title().split(" - Drawing mode enabled")[0])
        else:
            logging.warning("Image must be loaded to enable drawing mode!")
        

    def __toggle_fullscreen(self, state=None):
        """ Enable/disable the full screen mode """
        if state is not None:
            self.__fullscreen = state  # set state to fullscreen
        else:
            self.__fullscreen = not self.__fullscreen  # toggling the boolean
        # Hide menubar in fullscreen mode or show it otherwise
        if self.__fullscreen:
            self.__menubar_hide()
        else:  # show menubar
            self.__menubar_show()
        self.master.wm_attributes('-fullscreen', self.__fullscreen)  # fullscreen mode on/off

    def __menubar_show(self):
        """ Show menu bar """
        self.master.configure(menu=self.__menu.menubar)

    def __menubar_hide(self):
        """ Hide menu bar """
        self.master.configure(menu=self.__menu.empty_menu)

    def __motion(self):
        """ Track mouse pointer and handle its position """
        if self.__fullscreen:
            y = self.master.winfo_pointery()
            if 0 <= y < 20:  # if close to the upper side of the main window
                self.__menubar_show()
            else:
                self.__menubar_hide()

    def __keystroke(self, event):
        """ Language independent handle events from the keyboard
            Link1: http://infohost.nmt.edu/tcc/help/pubs/tkinter/web/key-names.html
            Link2: http://infohost.nmt.edu/tcc/help/pubs/tkinter/web/event-handlers.html """
        #print(event.keycode, event.keysym, event.state)  # uncomment it for debug purposes
        if event.state - self.__previous_state == 4:  # check if <Control> key is pressed
            for shortcut in self.__shortcuts:
                if event.keycode == shortcut[1]:
                    shortcut[2]()
        else:  # remember previous state of the event
            self.__previous_state = event.state

    def __default_geometry(self):
        """ Reset default geomentry for the main GUI window """
        self.__toggle_fullscreen(state=False)  # exit from fullscreen
        self.master.wm_state(self.__config.default_state)  # exit from zoomed
        self.__config.set_win_geometry(self.__config.default_geometry)  # save default to config
        self.master.geometry(self.__config.default_geometry)  # set default geometry

    def __resize_master(self):
        """ Save main window size and position into config file.
            BUG! There is a BUG when changing window from fullscreen to zoomed and then to normal mode.
            Main window somehow remembers zoomed mode as normal, so I have to explicitly set
            previous geometry from config INI file to the main window. """
        if self.master.wm_attributes('-fullscreen'):  # don't remember fullscreen geometry
            self.__bugfix = True  # fixing bug
            return
        if self.master.state() == 'normal':
            if self.__bugfix is True:  # fixing bug for: fullscreen --> zoomed --> normal
                self.__bugfix = False
                # Explicitly set previous geometry to fix the bug
                self.master.geometry(self.__config.get_win_geometry())
                return
            self.__config.set_win_geometry(self.master.winfo_geometry())
        self.__config.set_win_state(self.master.wm_state())

    def __create_widgets(self):
        """ Widgets for GUI are created here """
        # Create menu widget
        self.functions = {  # dictionary of functions for menu widget
            "destroy": self.destroy_,
            "toggle_fullscreen": self.__toggle_fullscreen,
            "default_geometry": self.__default_geometry,
            "set_image": self.__set_image,
            "set_params": self.__set_params,
            "change_templates_dir": self.__change_templates_dir,
            "preview_templates": self.template_viewer,
            "show_cells": self.show_template_matching,
            "optimal_cells": self.optimal_cells}
        
        self.parameters = {
            "Processing scale": 0.1,
            "Minimum area factor": 0.5,
            "Maximum area factor": 1.5,
            "Millable square factor": 1.4,
            "EPS factor": 0.5,
            "Minimum DBSCAN samples": 1,
            "Bounding circle with points": True,
            "Scale cells by circle": False,
            "Minimum diameter factor": 1.0,
            "Maximum diameter factor": 1.0,
            "Cross-correlation threshold": 0.6,
            "Number of template augmentations": 100,
            "Maximum template overlap": 0.0,
            "Number of cells to mill": 40,
            }
        
        self.__menu = Menu(self.master, self.__config, self.__shortcuts, 
                           self.functions, self.parameters)
        self.master.configure(menu=self.__menu.menubar)  # menu should be BEFORE iconbitmap, it's a bug
        # BUG! Add menu bar to the main window BEFORE iconbitmap command. Otherwise it will
        # shrink in height by 20 pixels after each open-close of the main window.
# =============================================================================
#         this_dir = os.path.dirname(os.path.realpath(__file__))  # directory of this file
#         if os.name == 'nt':  # Windows OS
#             self.master.iconbitmap(os.path.join(this_dir, 'logo.ico'))  # set logo icon
#         else:  # Linux OS
#             # ICO format does not work for Linux. Use GIF or black and white XBM format instead.
#             img = tk.PhotoImage(file=os.path.join(this_dir, 'logo.gif'))
#             self.master.tk.call('wm', 'iconphoto', self.master._w, img)  # set logo icon
# =============================================================================
        # Create placeholder frame for the image
        self.master.rowconfigure(0, weight=1)  # make grid cell expandable
        self.master.columnconfigure(0, weight=1)
        self.__placeholder = ttk.Frame(self.master)
        self.__placeholder.grid(row=0, column=0, sticky='nswe')
        self.__placeholder.rowconfigure(0, weight=1)  # make grid cell expandable
        self.__placeholder.columnconfigure(0, weight=1)
        # If image wasn't closed previously, open this image once again
        path = self.__config.get_opened_path()
        if path:
            self.__set_image(path=path)  # open previous image

    @handle_exception(0)    
    def __change_templates_dir(self):
        """ Open image in the GUI """
        path = askdirectory(title='Select a template directory',
                               initialdir=os.path.dirname(self.__config.get_templates_path()))
        if path == '': return
        self.__config.set_templates_path(path)
        self.__imframe.template_dir = path

    def __set_image(self, path=None, array=None):
        """ Close previous image and set a new one """
        self.__close_image()  # close previous image
        if array is not None:
            self.__imframe = CanvasImage(placeholder=self.__placeholder, array=array)
        else:
            self.__imframe = CanvasImage(placeholder=self.__placeholder, path=path)
        self.__imframe.grid()  # show it
        if array is not None:
            self.master.title(self.__default_title + ': Processing')
        else:
            self.master.title(self.__default_title + ': {}'.format(path))  # change window title
            self.__config.set_recent_path(path)  # save image path into config
        # Enable some menus
        self.__menu.set_state(state='normal')
        self.__menu.set_drawing_state(state='normal')
        # Focus canvas to enable key events
        self.__imframe.canvas.focus_set()

    @handle_exception(0)
    def __open_image(self):
        """ Open image in the GUI """
        path = askopenfilename(title='Select an image',
                               initialdir=self.__config.get_recent_path())
        if path == '': return
        # Check if it is an image
        if not CanvasImage.check_image(path):
            messagebox.showinfo('Not an image',
                                'This is not an image: "{}"\nPlease, select an image.'.format(path))
            self.__open_image()  # try to open new image again
            return
        self.__set_image(path)

    def __close_image(self):
        """ Close image """
        if self.__imframe:
            self.__imframe.destroy()
            self.__imframe = None
            self.master.title(self.__default_title)  # set default window title
            self.__menu.set_state(state='disabled')  # disable some menus
            self.__menu.set_drawing_state(state='disabled')
    

    def destroy_(self):
        """ Destroy the main frame object and release all resources """
        # Renamed to destroy_() in order to keep tk destroy() method, used below
        if self.__imframe:  # image is not closed
            self.__config.set_opened_path(self.__imframe.path)  # remember opened image
        else:  # image is closed
            self.__config.set_opened_path()  # no path
        self.__close_image()
        self.__config.destroy()
        logging.info('Close GUI')
        #self.quit() # Bug fix - leads to unresponsive window / having to restart kernel
        self.master.destroy()

    def __set_params(self, parameters):
        """ A function to allow the user to change settings from menu."""
        self.parameters = parameters
    
    @staticmethod
    def draw_rotated_squares(image, centers, square_size, angle, thickness=50):
        """Visualize the grid square detection results."""
        
        for center in centers:
            x, y = center
            # Calculate corner points of the square
            corners = np.array([
                [-square_size / 2, -square_size / 2],
                [square_size / 2, -square_size / 2],
                [square_size / 2, square_size / 2],
                [-square_size / 2, square_size / 2]
            ])
    
            # Create rotation matrix
            rotation_matrix = cv.getRotationMatrix2D((0, 0), angle, 1)
    
            # Rotate the corner points
            rotated_corners = np.dot(corners, rotation_matrix[:2, :2].T) + np.array([x, y])
    
            # Convert to integer coordinates
            rotated_corners = rotated_corners.astype(np.int32)
    
            # Draw the rotated square
            cv.polylines(image, [rotated_corners], isClosed=True, color=(0, 0, 255), thickness=thickness)
  
    
    def grid_squares(self):
        """ Perform grid square detection and visualize results on the GUI image."""

        def calculate_circle(points, centroid):
            """Use the furthest 5% of points to estimate a boundary circle."""
            
            # Calculate distances from the centroid
            distances = np.linalg.norm(points - centroid, axis=1)
        
            # Find the top 5% furthest points
            num_top_points = max(1, int(len(points) * 0.05))  # At least one point
            top_indices = np.argsort(distances)[-num_top_points:]
            top_distances = distances[top_indices]
        
            # Mean distance of these points
            radius = np.mean(top_distances)
        
            return (centroid[0], centroid[1], radius)
        
        def fit_circle(x, y):
            """Calculate the centroid given detected points and then calculate circle."""
            
            points = np.column_stack((x, y))
        
            # Calculate the centroid
            centroid = np.mean(points, axis=0)
        
            # Calculate the bounding circle
            bounding_circle = calculate_circle(points, centroid)
        
            return bounding_circle
        
        def rotate_circle(image, circle, angle):
            """Rotate the calculated circle on the image."""
            
            center_x, center_y, radius = circle
        
            # Create a mask for the circle
            mask = np.zeros(image.shape[:2], dtype=np.uint8)
            cv.circle(mask, (int(center_x), int(center_y)), int(radius), 255, -1)
        
            # Extract the circle from the original image using the mask
            circle_region = cv.bitwise_and(image, image, mask=mask)
        
            # Calculate the center for rotation
            (h, w) = circle_region.shape[:2]
            center = (int(center_x), int(center_y))
        
            # Get rotation matrix
            M = cv.getRotationMatrix2D(center, angle, 1.0)
        
            # Calculate the cosine and sine of the angle to get the new bounding dimensions
            abs_cos = abs(M[0, 0])
            abs_sin = abs(M[0, 1])
        
            # Compute new bounding dimensions
            new_w = int(h * abs_sin + w * abs_cos)
            new_h = int(h * abs_cos + w * abs_sin)
        
            # Adjust the rotation matrix to account for the translation
            M[0, 2] += new_w / 2 - center_x
            M[1, 2] += new_h / 2 - center_y
        
            # Perform the rotation
            rotated_circle = cv.warpAffine(circle_region, M, (new_w, new_h), flags=cv.INTER_LINEAR, borderMode=cv.BORDER_CONSTANT)
        
            # Rotate the mask
            rotated_mask = cv.warpAffine(mask, M, (new_w, new_h), flags=cv.INTER_LINEAR, borderMode=cv.BORDER_CONSTANT)
        
            return rotated_circle, rotated_mask, M
        
        def rotate_points(points, M):
            """Given points and a rotation matrix, convert to homogeneous
               coordinates and rotate (accounting for translation)."""
            
            points_homogeneous = np.hstack((points, np.ones((points.shape[0], 1))))
            rotated_points = points_homogeneous @ M.T
            return rotated_points[:, :2]
        
        def filter_points_within_circle(points, center, radius):
            """Exclude points outside of boundary circle."""
            
            distances = np.linalg.norm(points - center, axis=1)
            return points[distances <= radius]
        
        def create_grid_from_unique_points(points):
            """Find the unique x and y coordinates of detected squares to 
               create a grid of possible square positions."""
            
            unique_x = np.unique(points[:, 0])
            unique_y = np.unique(points[:, 1])
            grid_x, grid_y = np.meshgrid(unique_x, unique_y)
            return grid_x, grid_y
        
        def filter_grid_within_mask(grid_x, grid_y, mask):
            """Given a grid of points, exclude points outside of the mask
               of the rotated circle."""
            
            grid_points = np.column_stack((grid_x.ravel(), grid_y.ravel()))
            # Check which points are within the mask
            inside_mask = mask[grid_points[:, 1].astype(int), grid_points[:, 0].astype(int)] == 255
            filtered_grid_points = grid_points[inside_mask]
            return filtered_grid_points[:, 0], filtered_grid_points[:, 1]
        
        def detect_squares_around_centers(points, eps=5, min_samples=1):
            """Use DBSCAN algorithm to cluster detected grid points and
               refine the positions of the square centers."""
            
            clustering = DBSCAN(eps=eps, min_samples=min_samples).fit(points)
            labels = clustering.labels_
        
            unique_labels = np.unique(labels)
            centers = []
            for label in unique_labels:
                if label == -1:  # Ignore noise points
                    continue
                cluster_points = points[labels == label]
                center = np.mean(cluster_points, axis=0)
                centers.append(center)
        
            return np.array(centers)

        def calculate_boundary_points(center_x, center_y, side_length):
            """Given a center and square side length, calculate the corners."""
            
            half_side = side_length / 2
            top_left = (center_x - half_side, center_y - half_side)
            top_right = (center_x + half_side, center_y - half_side)
            bottom_right = (center_x + half_side, center_y + half_side)
            bottom_left = (center_x - half_side, center_y + half_side)
            return [top_left, top_right, bottom_right, bottom_left]
        
        def filter_square_centers(square_centers, full_center, side_length):
            """Filter the grid square centers to exclude area outside of
               millable square."""
            
            boundary_points = calculate_boundary_points(*full_center, side_length)
            min_x = min(point[0] for point in boundary_points)
            max_x = max(point[0] for point in boundary_points)
            min_y = min(point[1] for point in boundary_points)
            max_y = max(point[1] for point in boundary_points)
            
            filtered_centers = square_centers[
                (square_centers[:, 0] >= min_x) & (square_centers[:, 0] <= max_x) &
                (square_centers[:, 1] >= min_y) & (square_centers[:, 1] <= max_y)
            ]
            return filtered_centers
  
        if not self.__imframe or not self.__imframe.path:
            logging.warning("No image loaded!")
            return
    
        # Load the original image
        image_path = self.__imframe.path
        full_image = cv.imread(image_path)
        if full_image is None:
            logging.warning(f"Failed to load image from {image_path}")
            return
    
        # Downsize the image for faster processing
        processing_scale = self.parameters["Processing scale"]  # Scale down based on scale
        processing_image = cv.resize(
            full_image, 
            None, 
            fx=processing_scale, 
            fy=processing_scale, 
            interpolation=cv.INTER_AREA
        )
        orig_img = np.copy(processing_image)
        
        # Convert to grayscale and preprocess
        gray = cv.cvtColor(processing_image, cv.COLOR_BGR2GRAY)
        gray = (((gray - np.min(gray)) / np.max(gray)) * 255).astype(np.uint8)
        blur = cv.GaussianBlur(gray, (15, 15), 0)
        thresh = cv.threshold(blur, 0, 255, cv.THRESH_BINARY_INV + cv.THRESH_OTSU)[1]
        square_area = (self.__imframe.square_size / self.__imframe.imscale * processing_scale)**2
    
        # Detect contours
        #draw = np.copy(orig_img) # Optional intermediate drawing
        cnts, _ = cv.findContours(thresh, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
        
        angles = []

        min_area = self.parameters["Minimum area factor"] * square_area
        max_area = self.parameters["Maximum area factor"] * square_area
        image_number = 0
        
        # Prepare lists to store coordinates and centroids
        x_data = []
        y_data = []
        centroids = []
        
        for c in cnts:
            area = cv.contourArea(c)
            if min_area < area < max_area:
                rect = cv.minAreaRect(c)
                box = cv.boxPoints(rect)
                box = np.intp(box)  # Use intp to convert to integer
        
                # Draw grid square
                #cv.polylines(draw, [box], True, (255, 255, 255), 5)
                image_number += 1
                angles.append(rect[2])
        
                # Calculate centroid
                M = cv.moments(c)
                if M["m00"] != 0:
                    cX = int(M["m10"] / M["m00"])
                    cY = int(M["m01"] / M["m00"])
                    centroids.append((cX, cY))
        
                    # Optionally draw the centroid on the image
                    #cv.circle(draw, (cX, cY), 5, (0, 255, 0), -1)  # Green dot for centroid
        
                # Create a mask for the square
                mask = np.zeros(orig_img.shape[:2], dtype=np.uint8)
                cv.fillPoly(mask, [box], 255)
        
                # Find points within the square
                points_within_square = np.column_stack(np.where(mask == 255))
                for point in points_within_square:
                    y_data.append(point[0])
                    x_data.append(point[1])
        
        # Convert lists to numpy arrays for easier manipulation later
        x_data = np.array(x_data)
        y_data = np.array(y_data)
        centroids = np.array(centroids)
            
        orig_img = np.copy(processing_image)
        if self.parameters["Bounding circle with points"]:
            bounding_circle = fit_circle(x_data, y_data)
            
            # Get the center and radius of the circle
            center = np.array([bounding_circle[0], bounding_circle[1]])
            radius = bounding_circle[2]
        
        else:
            center = np.array([processing_image.shape[1]//2,
                               processing_image.shape[0]//2])
            points = np.column_stack((x_data, y_data))
            distances = np.linalg.norm(points - center, axis=1)
            radius = max(distances)
            bounding_circle = [*center, radius]
        
        # Prepare points within the circle
        points_within_circle = np.array(centroids)
        
        # Filter points to keep only those within the circle
        filtered_points = filter_points_within_circle(points_within_circle, center, radius)
        
        # Rotate the circle and get the rotation matrix and mask
        rotated_circle_image, rotated_mask, rotation_matrix = rotate_circle(orig_img, bounding_circle, np.mean(angles))  # Use positive angle
        full_rotated_circle_image, full_rotated_mask, full_rotation_matrix = rotate_circle(full_image, 
                                                                                           [coord/processing_scale for coord in bounding_circle],
                                                                                           np.mean(angles))  # Use positive angle
        
        # Rotate the points
        rotated_points = rotate_points(filtered_points, rotation_matrix)
        
        # Create a grid from the unique x and y values of the rotated points
        grid_x, grid_y = create_grid_from_unique_points(rotated_points)
        
        # Filter the grid points to only include those within the rotated mask
        filtered_grid_x, filtered_grid_y = filter_grid_within_mask(grid_x, grid_y, rotated_mask)
        
        # Detect square centers using DBSCAN
        square_size = (self.__imframe.square_size / self.__imframe.imscale * processing_scale)
        eps = square_size * self.parameters["EPS factor"]
        min_samples = self.parameters["Minimum DBSCAN samples"]
        filtered_grid_points = np.column_stack((filtered_grid_x, filtered_grid_y))
        square_centers = detect_squares_around_centers(filtered_grid_points, eps=eps, min_samples=min_samples)
        full_square_centers = square_centers / processing_scale
        
        
        # Back-project to the original image coordinates
        M_inv = cv.invertAffineTransform(full_rotation_matrix)
        original_square_centers = rotate_points(full_square_centers, M_inv)
        
        # Filter to only include cells in millable area
        millable_centers = filter_square_centers(original_square_centers,
                                                 center/processing_scale,
                                                 radius/processing_scale*self.parameters["Millable square factor"])
        self.__millable_centers = millable_centers
        self.__full_square_size = square_size / processing_scale
        self.__square_rotation_angle = -np.mean(angles)
        self.__menu.set_2kv_state('normal')
        self.__menu.set_show_squares_state('normal')
        
        # Draw the detected squares on the original image
        self.draw_rotated_squares(full_image, self.__millable_centers, 
                             self.__full_square_size, 
                             self.__square_rotation_angle,
                             thickness=50)
        
        logging.info("Grid squares detected")
        self.master.title(self.__default_title+": Grid squares detected!")
        
        try:
            # Try to store in RAM as a class attribute
            self.__detected_squares_array = full_image
        except:
            # Otherwise, save to a file, and user has to open it to visualize
            logging.warning("Unable to store detected grid squares image")
            dir_path = os.path.dirname(os.path.abspath(self.__imframe.path))
            logging.info("Saving to file: {}\\grid_squares.tif".format(dir_path))
            image = Image.fromarray(full_image)
            # Save the image as a TIFF file
            image.save("{}\\grid_squares.tif".format(dir_path), format="TIFF")
        
        
    def show_grid_squares(self):
        """ A function for displaying the visualizations from draw_rotated_squares """
        if self.__millable_centers is None:
            logging.warning("You must run grid square detection first!")
            return
        if self.__detected_squares_array is None:
            if self.__imframe.path is None:
                logging.warning("You must have an image loaded!")
                return
            else:
                full_image = cv.imread(self.__imframe.path)
                self.draw_rotated_squares(full_image, self.__millable_centers,
                                                                          self.__full_square_size, self.__square_rotation_angle)
                self.__detected_squares_array = full_image

        # Display the image with detected grid squares
        self.__set_image(array=self.__detected_squares_array)
        self.master.title(self.master.title() + " - Grid square display")
        self.__detected_squares_array = None # Clear duplicate from RAM
        
    def __load_templates(self, scaling=False):
        """ A function to load the templates either for template matching (with scaling) or for previews (without) """
        templates_path = self.__config.get_templates_path()
        template_files = [os.path.join(templates_path, template_file) for template_file in os.listdir(templates_path)]
        if scaling:
            self.__full_circle_size = round(self.__imframe.circle_size / self.__imframe.imscale)
        template_arrays = []
        for template_file in template_files:
            # Load template images
            template_array = cv.imread(template_file)
            
            # Scale maximum dimension to diameter of circle
            max_dim = max(template_array.shape)
            if scaling:
                scale = self.__full_circle_size / max_dim
            else:
                scale = 1
            
            # Resize and min-max normalize template
            template_array = cv.resize(template_array, None, fx=scale, fy=scale, interpolation=cv.INTER_LANCZOS4)
            array_min = np.min(template_array)
            array_max = np.max(template_array)
            template_array = (template_array - array_min) / (array_max - array_min)
            
            template_arrays.append([template_array, template_file])
            
        self.__template_arrays = template_arrays
        
    def template_viewer(self):
        """ Open template viewer to preview templates """
        self.__load_templates(scaling=False)
        ArrayPhotoViewer(self.master, self.__template_arrays)
        
    def multi_template_matching(self):
        """ Run multi template matching with given templates and augmentation """
        self.__template_arrays = None
        self.__load_templates(scaling=self.parameters["Scale cells by circle"])
        if self.__imframe.path is None:
            logging.warning("Must have a 2 kV image loaded!")
            return

        # Load the original image
        image_path = self.__imframe.path
        full_image = cv.imread(image_path)
        if full_image is None:
            logging.warning(f"Failed to load image from {image_path}")
            return

        # Downsize the image for faster processing
        processing_scale = self.parameters["Processing scale"]  # Scale down based on scale
        processing_image = cv.resize(
            full_image, 
            None, 
            fx=processing_scale, 
            fy=processing_scale, 
            interpolation=cv.INTER_AREA
        )
        
        processing_image = (processing_image - np.min(processing_image)) / np.ptp(processing_image)
        processing_image = (processing_image*255).astype(np.uint8)
        processing_image = cv.cvtColor(processing_image, cv.COLOR_BGR2GRAY)
        
        # Basic transformations for data augmentation on templates
        
        def random_select(lst):
          shuffled = copy.copy(lst)
          max_n = len(lst)
          n = random.randint(0, max_n)
          random.shuffle(shuffled)
          return shuffled[:n]
        
        def apply_functions(functions, array):
          result = array
          for function in functions:
            result = function(result)
          return result
        
        def rand_hstretch(array):
          height, width = array.shape[:]
          scale_min = 1
          scale_max = self.parameters["Maximum diameter factor"]
          scale = random.uniform(scale_min, scale_max)
          size = (round(scale*width), height)
          res = cv.resize(array, size, interpolation = cv.INTER_CUBIC)
          return res
        
        def rand_hshrink(array):
          height, width = array.shape[:]
          scale_min = self.parameters["Minimum diameter factor"]
          scale_max = 1
          scale = random.uniform(scale_min, scale_max)
          size = (round(scale*width), height)
          res = cv.resize(array, size, interpolation = cv.INTER_AREA)
          return res
        
        def rand_vstretch(array):
          height, width = array.shape[:]
          scale_min = 1
          scale_max = self.parameters["Maximum diameter factor"]
          scale = random.uniform(scale_min, scale_max)
          size = (width, round(scale*height))
          res = cv.resize(array, size, interpolation = cv.INTER_CUBIC)
          return res
        
        def rand_vshrink(array):
          height, width = array.shape[:]
          scale_min = self.parameters["Minimum diameter factor"]
          scale_max = 1
          scale = random.uniform(scale_min, scale_max)
          size = (width, round(scale*height))
          res = cv.resize(array, size, interpolation = cv.INTER_AREA)
          return res
        
        def rand_flip(array):
          axis = random.randint(0,2)
          if axis == 0:
            flipped = np.flip(array, 0)
          elif axis == 1:
            flipped = np.flip(array, 1)
          else:
            flipped = np.flip(array, 0)
            flipped = np.flip(flipped, 1)
          return flipped
        
        def rand_rotate(array):
          degrees_min = 0
          degrees_max = 4
          degrees = random.randint(degrees_min, degrees_max)
          rotated = ndimage.rotate(array, 90*degrees)
          return rotated
          
        def transform(array, funcs):
            a = np.copy(array)
            ops = random_select(funcs)
            a_aug = apply_functions(ops, a)
            return a_aug
        
        funct_list = [rand_hstretch, rand_hshrink, rand_vstretch, rand_vshrink,
                          rand_flip, rand_rotate]

        full_templates = []
        for template in self.__template_arrays:
            scaled_template = cv.resize(template[0], None, fx=processing_scale, fy=processing_scale, interpolation=cv.INTER_AREA)
            scaled_template = (scaled_template * 255).astype(np.uint8)
            scaled_template = cv.cvtColor(scaled_template, cv.COLOR_BGR2GRAY)
            mult_templates = [("{} - {}".format(template[1], n), transform(scaled_template, funct_list).astype(np.uint8)) for n in range(self.parameters["Number of template augmentations"])]
            full_templates += mult_templates

        hits = matchTemplates(listTemplates=full_templates, image=processing_image, 
                              score_threshold=self.parameters["Cross-correlation threshold"],
                              maxOverlap=self.parameters["Maximum template overlap"])
        
        self.hits = hits
        logging.info("Cells detected!")
        self.master.title(self.__default_title + " - Cells detected!")
        self.__menu.set_cells_state('normal')
        
    def show_template_matching(self):
        """  """
        # Load the original image
        image_path = self.__imframe.path
        full_image = cv.imread(image_path)
        
        for label, bbox, _ in self.hits:
            x,y,w,h = bbox
            x *= 10; y *= 10; w *= 10; h *= 10
            cv.rectangle(full_image, (x, y), (x + w, y + h), color = (255,255,0), thickness = 50)
        
        self.__set_image(array=full_image)
        self.__imframe.path = image_path
        
    def optimal_cells(self):
        def find_closest_coordinates(array1, array2, n):
            """
            Find the n coordinates in array1 that are closest to some point in array2.
            
            Args:
                array1 (numpy.ndarray): An array of shape (m, d), representing m points in d-dimensional space.
                array2 (numpy.ndarray): An array of shape (k, d), representing k points in d-dimensional space.
                n (int): Number of closest points to find in array1.
            
            Returns:
                numpy.ndarray: An array of the n closest points in array1.
            """
            # Calculate the pairwise distances between points in array1 and array2
            distances = np.linalg.norm(array1[:, None, :] - array2[None, :, :], axis=-1)
            
            # Find the minimum distance for each point in array1 to any point in array2
            min_distances = np.min(distances, axis=1)
            
            # Get the indices of the n smallest distances
            closest_indices = np.argsort(min_distances)[:n]
            
            # Return the n closest points from array1
            return array1[closest_indices]
        
        def find_top_n_points(array1, array2, n, square_size, rotation_angle):
            """
            Find the top n points in array1 closest to array2 centers, ensuring no two points come from the same square.
        
            Args:
                array1 (numpy.ndarray): Points to evaluate, shape (m, 2).
                array2 (numpy.ndarray): Square centers, shape (k, 2).
                n (int): Number of points to select.
                square_size (float): Size of the square (side length).
                rotation_angle (float): Rotation angle of the squares in degrees.
        
            Returns:
                list: List of tuples [(point, center), ...], containing n closest points and their centers.
            """
            def is_inside_square(point, center, size, angle):
                """Check if a point is inside a rotated square."""
                # Translate point relative to square center
                rel_point = point - center
        
                # Rotate the point to align with the square axes
                angle_rad = np.radians(-angle)
                rotation_matrix = np.array([
                    [np.cos(angle_rad), -np.sin(angle_rad)],
                    [np.sin(angle_rad), np.cos(angle_rad)]
                ])
                rotated_point = rel_point @ rotation_matrix.T
        
                # Check if the point lies within the square's bounds
                half_size = size / 2
                return (
                    -half_size <= rotated_point[0] <= half_size and
                    -half_size <= rotated_point[1] <= half_size
                )
        
            # Calculate pairwise distances
            distances = np.linalg.norm(array1[:, None, :] - array2[None, :, :], axis=-1)
            
            # Store which square each point belongs to (or None if outside all squares)
            point_to_square = [-1] * len(array1)
            for i, center in enumerate(array2):
                for j, point in enumerate(array1):
                    if is_inside_square(point, center, square_size, rotation_angle):
                        point_to_square[j] = i  # Assign square index
        
            # Sort points by their closest distance to any square center
            sorted_indices = np.argsort(np.min(distances, axis=1))
            
            # Select the top n points, ensuring no two points belong to the same square
            selected_points = []
            used_squares = set()
            for idx in sorted_indices:
                square_idx = point_to_square[idx]
                if square_idx not in used_squares:  # Ensure no duplicate square usage
                    selected_points.append((array1[idx], array2[np.argmin(distances[idx])]))
                    used_squares.add(square_idx)
                if len(selected_points) == n:
                    break
            
            return selected_points
        
        centers = []
        for label, bbox, _ in self.hits:
            x,y,w,h = bbox
            x *= 10; y *= 10; w *= 10; h *= 10
            centers.append([x+w//2, y+h//2])
        self.__cell_centers = np.array(centers)
        #self.__optimal_cells, plot_squares = find_closest_coordinates(self.__cell_centers,
                                                      #self.__millable_centers,
                                                      #self.parameters["Number of cells to mill"])
        
        cells_and_centers = find_top_n_points(self.__cell_centers, 
                                              self.__millable_centers,
                                              self.parameters["Number of cells to mill"],
                                              self.__full_square_size,
                                              self.__square_rotation_angle)
        self.__optimal_cells = np.array([data[0] for data in cells_and_centers])
        plot_squares = np.array([data[1] for data in cells_and_centers])
        # Load the original image
        if self.__imframe.path is None:
            logging.warning("Must have an image loaded!")
            return
        
        image_path = self.__imframe.path
        full_image = cv.imread(image_path)
        self.draw_rotated_squares(full_image, plot_squares, 
                                  self.__full_square_size, self.__square_rotation_angle)
        for x,y in self.__optimal_cells:
            cv.circle(full_image, (x, y), 50, (0, 255, 0), -1)
        
        self.__set_image(array=full_image)